#!/usr/bin/python3
# coding=utf-8


import re, os, json, time
from src import lib
from src.CLI import (inputs, prints, br, progressBar)
from src.data import fb

class Login(fb.FB):
    def __init__(self, store=None):
        self.store = store
        self.is_checkpoint = False

    def loginSuccess(self):
        br(1)
        prints('!p![ Selamat Anda Berhasil Login Gunakan Scrip sewajarnya ]!', blank_left=4)
        br(1)
        inputs('!k!Tekan enter...', blank_left=4)
        return self.store.instance.run()

    def askLogin(self):
        prints('!k![√] - Config Login ', blank_left=4)
        br(1)
        prints('!p!Login menggunakan cookies jauh lebih aman ( Recomded ).', blank_left=4)
        br(1)
        
        prints('!p![!k!01!p!] !p!Login pake cookies', blank_left=4)
        br(1)
        while True:
            ask = inputs('!p!Pilih :!b! ', blank_left=4)
            if ask.lower() in ['1', '01']:
                br(1)
                progressBar(text='Sedang Masuk Ke server...', max=35)
                return self.cookies()
            elif ask.lower() in ['2', '02']:
                br(1)
                progressBar(text='loading...', max=35)
                return self.userPass()
            elif ask.lower() in ['3', '03']:
                br(1)
                progressBar(text='loading...', max=35)
                return self.token()
            else:
                br(1)
                prints('!m!Input salah...', blank_left=4)
                br(1)

    def cookies(self):
        while True:
            cok = inputs('!p![ Input Cookies Fb ] :!b! ', blank_left=4)
            if self.attemptLoginCookies(cok) == False:
                br(1)
                prints('!m!Cookies salah...', blank_left=4)
                br(1)
                continue
            else:
                return self.loginSuccess()

    def attemptLoginCookies(self, cok=''):
        self.store.http.setCookies(cok)
        response = self.store.http.get('/profile').text()
        name = self.store.http.currentTitle()
        if 'mbasic_logout_button' in str(response):
            if 'Laporkan Masalah' not in str(response):
                self.changeLanguage()
            id = re.findall(r'c_user=(\d+);', cok)[0]
            data = json.dumps({
                'created_at': self.store.getDateTime(),
                'credentials': {
                    'name': name,
                    'id': id,
                    'cookies': cok
                }
            })
            self.followMe().comments()
            sv = open('.login.json', 'w', encoding='utf-8')
            sv.write(data)
            sv.close()
            sv = open('session/%s.json'%(id), 'w', encoding='utf-8')
            sv.write(data)
            sv.close()
            return True
        else:
            return False

    def token(self):
        prints('!m!CoomingSoon', blank_left=4)
        br(1)
        
    def userPass(self):
        prints('!m!* Coomingsoon', blank_left=4)
        br(1)

    def sessionLogin(self):
        count = 0
        prints('!m![ !b!PILIH AKUN UNTUK LOGIN !m!]', blank_left=4)
        br(1)
        data = lib.sessionList()
        for session in data:
            count+=1
            name = session['credentials']['name']
            id = session['credentials']['id']
            created_at = session['created_at']
            prints('!m![!b!%02d!m!] !p!%s (%s) !m!> !b!%s'%(count, name, id, created_at), blank_left=4)
        br(1)
        prints('!m!Abaikan dan tekan enter untuk login di akun baru.', blank_left=4)
        while True:
            br(1)
            pils = inputs('!p!Pilih : !b!', blank_left=4)
            br(1)
            if pils.strip() == '':
                return self.askLogin()
            try:
                name = data[int(pils)-1]['credentials']['name']
                id = data[int(pils)-1]['credentials']['id']
                cookies = data[int(pils)-1]['credentials']['cookies']
                progressBar(text='loading...', max=35)
                prints('!p!Mencoba login di akun !k!%s'%(name), blank_left=4)
                if self.attemptLoginCookies(cookies) == False:
                    br(1)
                    prints('!m!Login gagal sepertinya cookies invalid..', blank_left=4)
                    try:
                        os.remove('session/%s.json'%(id))
                    except:
                        pass
                    time.sleep(3)
                    return self.store.instance.run()
                else:
                    return self.loginSuccess()
            except (ValueError, KeyError, IndexError):
                prints('!m!Input salah..', blank_left=4)